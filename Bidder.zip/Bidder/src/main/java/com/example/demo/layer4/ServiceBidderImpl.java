
package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Bidder;
import com.example.demo.layer3.BidderRepoImpl;
@Service
public class ServiceBidderImpl implements ServiceBidderRepo {
	@Autowired
	BidderRepoImpl bidderRepoImpl;

	@Transactional
	public void insertBidder(Bidder bobj) {
		// TODO Auto-generated method stub
		 bidderRepoImpl.insertBidder(bobj);

	}

	@Transactional
	public void updateBidder(Bidder bobj) {
		// TODO Auto-generated method stub
		bidderRepoImpl.updateBidder(bobj);

	}

	@Override
	public Bidder selectBidder(int b_bid) {
		// TODO Auto-generated method stub
		return bidderRepoImpl.selectBidder(b_bid);
	}

	@Override
	public List<Bidder> selectAllBidder() {
		// TODO Auto-generated method stub
		return bidderRepoImpl.selectAllBidder();
	}

	@Transactional
	public void removeBidder(int b_bid) {
		// TODO Auto-generated method stub
	bidderRepoImpl.removeBidder(b_bid);

	}

}
