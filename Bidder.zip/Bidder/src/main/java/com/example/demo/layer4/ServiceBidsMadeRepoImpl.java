package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Bids_Made;
import com.example.demo.layer3.Bids_MadeRepoImpl;


@Service
public class ServiceBidsMadeRepoImpl implements ServiceBidsMadeRepo {

	@Autowired
   Bids_MadeRepoImpl bids_MadeRepoImpl;	
	
	@Override
	public void insertBidsMade(Bids_Made Bids_Made) {
		// TODO Auto-generated method stub
		bids_MadeRepoImpl.bidsMadeInsert(Bids_Made);
	}

	@Override
	public void updateBidsMade(Bids_Made bidMade) {
		// TODO Auto-generated method stub
		bids_MadeRepoImpl.updateb_bidding_id(bidMade);
	}

	@Override
	public void deleteBidsMade(int b_bidding_id) {
		// TODO Auto-generated method stub
		bids_MadeRepoImpl.deleteb_bidding_id(b_bidding_id);
	}

	@Override
	public Bids_Made selectBidsMade(int b_bidding_id) {
		// TODO Auto-generated method stub
		return bids_MadeRepoImpl.selectBids_Made(b_bidding_id);
	}

	@Override
	public List <Bids_Made> selectAllBidsMade() {
		// TODO Auto-generated method stub
		return bids_MadeRepoImpl.selectAllBids_Made();
	}



}
