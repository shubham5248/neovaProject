package com.example.demo.layer3;

import java.util.List;



import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Bids_Made;
@Repository
public class Bids_MadeRepoImpl extends BaseRepo implements Bids_MadeRepo {

	@Transactional
	public void bidsMadeInsert(Bids_Made bmObj) {
		super.persist(bmObj);
		
	}

	
	public Bids_Made selectBids_Made(int b_bidding_id) {
		// TODO Auto-generated method stub
		return super.find(Bids_Made.class,  b_bidding_id);
	}


	public List<Bids_Made> selectAllBids_Made() {
		// TODO Auto-generated method stub
		return super.findAll("Bids_Made");
	}

	@Transactional
	public void updateb_bidding_id(Bids_Made bmObj) {
		// TODO Auto-generated method stub
		super.merge(bmObj);
	}

	@Transactional
	public void deleteb_bidding_id(int b_bidding_id) {
		// TODO Auto-generated method stub
		super.remove(Bids_Made.class, b_bidding_id);
	}

}
