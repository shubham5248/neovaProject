package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Bidder;
@Repository
interface Bidderrepo {
	
	void insertBidder(Bidder bobj);
	
	void updateBidder (Bidder bobj);
	
	Bidder selectBidder(int b_bid);
	
	List<Bidder> selectAllBidder();
	
	void removeBidder(int b_bid);

}
