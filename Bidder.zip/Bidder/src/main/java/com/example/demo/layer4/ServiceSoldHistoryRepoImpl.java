package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.layer2.SoldHistory;
import com.example.demo.layer3.SoldHistoryImpl;
@Service
public class ServiceSoldHistoryRepoImpl implements ServiceSoldHistoryRepo {
	
     @Autowired
	SoldHistoryImpl soldHistoryImpl;
	
	@Override
	public void insertSoldHistory(SoldHistory soldHistory) {
		// TODO Auto-generated method stub
		soldHistoryImpl.insertSoldHistory(soldHistory);
	}

	@Override
	public void updateSoldHistory(SoldHistory soldHistory) {
		// TODO Auto-generated method stub
		soldHistoryImpl.updateSoldHistory(soldHistory);
	}

	@Override
	public void deleteSoldHistory(int SrNo) {
		// TODO Auto-generated method stub
		soldHistoryImpl.deleteSoldHistory(SrNo);
	}

	@Override
	public SoldHistory selectSoldHistory(int SrNo) {
		// TODO Auto-generated method stub
		return soldHistoryImpl.selectSoldHistory(SrNo);
	}

	@Override
	public List<SoldHistory> selectAllSoldHistory() {
		// TODO Auto-generated method stub
		return soldHistoryImpl.selectSoldHistorys();
	}



}
