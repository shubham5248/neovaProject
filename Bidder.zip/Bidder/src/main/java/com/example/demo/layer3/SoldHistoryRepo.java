package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.SoldHistory;
@Repository
public interface SoldHistoryRepo {
	
	
	void insertSoldHistory(SoldHistory shobj);
	
	void  deleteSoldHistory(int bid);
	
	void updateSoldHistory(SoldHistory shobj);
	
	SoldHistory selectSoldHistory (int bid);
	
	List<SoldHistory> selectSoldHistorys();
	
	
	

}
