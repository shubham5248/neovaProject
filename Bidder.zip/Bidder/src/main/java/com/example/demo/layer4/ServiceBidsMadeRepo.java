package com.example.demo.layer4;


import java.util.List;

import org.springframework.stereotype.Service;


import com.example.demo.layer2.Bids_Made;

@Service
interface ServiceBidsMadeRepo {

	
	public void insertBidsMade (Bids_Made Bids_Made);
	
	public void  updateBidsMade( Bids_Made bidMade);
	
	public void deleteBidsMade (int b_bidding_id);
	
	public Bids_Made selectBidsMade ( int b_bidding_id);
	
	public List<Bids_Made> selectAllBidsMade();

}
