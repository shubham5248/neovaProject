package com.example.demo.layer2;

import java.time.LocalDate;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


import javax.persistence.ManyToOne;

import javax.persistence.Table;

@Entity
@Table(name= "bidsmade01")
public class Bids_Made {
	@Id
	@GeneratedValue
	private int b_bidding_id;

	
	private int b_amount;
	
	private LocalDate b_date;

     
	@ManyToOne
//	@JoinColumn(name = "B_Id")
	private Bidder bidder;
	


	public int getB_bidding_id() {
		return b_bidding_id;
	}



	public void setB_bidding_id(int b_bidding_id) {
		this.b_bidding_id = b_bidding_id;
	}



	public int getB_amount() {
		return b_amount;
	}



	public void setB_amount(int b_amount) {
		this.b_amount = b_amount;
	}



	public LocalDate getB_date() {
		return b_date;
	}



	public void setB_date(LocalDate b_date) {
		this.b_date = b_date;
	}



	public Bidder getBidder() {
		return bidder;
	}



	public void setBidder(Bidder bidder) {
		this.bidder = bidder;
	}



	@Override
	public String toString() {
		return "Bids_Made [b_bidding_id=" + b_bidding_id + ", b_amount=" + b_amount + ", b_date=" + b_date + ", bidder="
				+ bidder + "]";
	}

	

}
