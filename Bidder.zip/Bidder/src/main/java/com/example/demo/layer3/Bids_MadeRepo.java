package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Bids_Made;


@Repository
interface Bids_MadeRepo {
public void bidsMadeInsert(Bids_Made bmObj); //C
	
public Bids_Made selectBids_Made(int b_bidding_id); //R

	public List<Bids_Made> selectAllBids_Made(); //RA
	
	public void updateb_bidding_id(Bids_Made bmObj); //U
	
	public void deleteb_bidding_id(int b_bidding_id); //D

}
