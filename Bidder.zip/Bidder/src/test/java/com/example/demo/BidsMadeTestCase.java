package com.example.demo;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Bids_Made;
import com.example.demo.layer3.Bids_MadeRepoImpl;

@SpringBootTest
public class BidsMadeTestCase {
	
	@Autowired
	Bids_MadeRepoImpl bidsRepoImpl;
	
	
	@Test
	void insertBids_Made() {
		Bids_Made bids=new Bids_Made();
		
		bids.setB_amount(4300);
		bids.setB_date(LocalDate.of(2021, 02, 22));
		bidsRepoImpl.bidsMadeInsert(bids);
		
	}
	
	@Test
	void updateBids_Made() {
		Bids_Made bids =null;
		bids = bidsRepoImpl.find(Bids_Made.class, 45);
		
		bids.setB_amount(1503400);
     	bids.setB_date(LocalDate.of(2021, 03, 30));
		
		
		bidsRepoImpl.updateb_bidding_id(bids);
		
	}
	
	
	
	
	
	
	@Test
	void selectBids() {
		Bids_Made bidsMade =bidsRepoImpl.find(Bids_Made.class, 45);
	//	System.out.println("bidsMade"+ bidsMade.getB_bidding_id());
		System.out.println("bidsMade"+ bidsMade.getB_amount());
		System.out.println("bidsMade"+ bidsMade.getB_date());
	}
	
	
	
	
	@Test
	void selectAllBids() {
		List<Bids_Made> bidsMadeList =   bidsRepoImpl.findAll("Bids_Made");
		
		for(	Bids_Made bidsMade : bidsMadeList) {
			System.out.println("bidsMade"+ bidsMade.getB_amount());
			System.out.println("bidsMade"+ bidsMade.getB_date());
		}
	}
	
	@Test
	void deleteBidsMade() {
	bidsRepoImpl.deleteb_bidding_id(45);
	
	List<Bids_Made> bidsMadeList =   bidsRepoImpl.findAll("Bids_Made");
	
	for(	Bids_Made bidsMade : bidsMadeList) {
		System.out.println("bidsMade"+ bidsMade.getB_amount());
		System.out.println("bidsMade"+ bidsMade.getB_date());
	}
	}
	

}



