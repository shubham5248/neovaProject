package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Bidder;

import com.example.demo.layer3.BidderRepoImpl;


@SpringBootTest
class BidderTestCase {
	
	@Autowired
	BidderRepoImpl repoImpl;
	

	


	@Test
	void insertBidder() {
		Bidder bidder= new Bidder();
		bidder.setB_name("Yogesh");
		bidder.setB_email("rushi051@gmail.com");
		bidder.setB_contact_no(9888682987l);
		bidder.setB_address("Pawna Nagar");
		bidder.setB_trader_license("RUS12345");
		bidder.setB_pincode(411033);
		bidder.setB_city("Pune");
		bidder.setB_state("Maharashtra");
		bidder.setB_adharcard(123432178945l);
		bidder.setB_account_number(654254987l);
		bidder.setB_ifsc("FISC132521");
		bidder.setB_bank_name("ICICI Bank");
		
		repoImpl.insertBidder(bidder);
	}
	
	@Test
	void updateBidder()
	{
		
		Bidder bidder=null;
		bidder=repoImpl.find(Bidder.class, 7);
		Assertions.assertNotNull(bidder);
	
//	  bidder.setB_bid(7);
		bidder.setB_name("Ram");
		bidder.setB_email("ram051@gmail.com");
		bidder.setB_contact_no(9888696987l);
		bidder.setB_address("Pimpri Chinchwad");
		bidder.setB_trader_license("RAM12345");
		bidder.setB_pincode(411033);
		bidder.setB_city("Pune");
		bidder.setB_state("Maharashtra");
		bidder.setB_adharcard(123432178945l);
		bidder.setB_account_number(654644987l);
		bidder.setB_ifsc("FISC132981");
		bidder.setB_bank_name("ICICI Bank");
		
		repoImpl.updateBidder(bidder);
	}
	
	@Test
	void deleteBidder()
	{
      Bidder delete=null;
    	delete=	  repoImpl.find(Bidder.class, 10);
      repoImpl.removeBidder(10);
	}
	
	@Test
	void findBidder() {
		Bidder bidObj=repoImpl.find(Bidder.class, 36);
		
	System.out.println("bidder:"+bidObj.getB_name());	
	System.out.println("bidder:"+bidObj.getB_email());
	System.out.println("bidder:"+bidObj.getB_contact_no());	
	System.out.println("bidder:"+bidObj.getB_address());
	System.out.println("bidder:"+bidObj.getB_trader_license());	
	System.out.println("bidder:"+bidObj.getB_pincode());
	System.out.println("bidder:"+bidObj.getB_city());	
	System.out.println("bidder:"+bidObj.getB_state());
	System.out.println("bidder:"+bidObj.getB_adharcard());	
	System.out.println("bidder:"+bidObj.getB_account_number());
	System.out.println("bidder:"+bidObj.getB_ifsc());	
	System.out.println("bidder:"+bidObj.getB_bank_name());
	}
	

	@Test
	void selectAllBidder() {
		List <Bidder> bidderList = new ArrayList<Bidder>();
				
				bidderList =repoImpl.selectAllBidder();
		for(Bidder bidObj: bidderList){
			
			System.out.println("bidder:"+bidObj.getB_name());	
			System.out.println("bidder:"+bidObj.getB_email());
			System.out.println("bidder:"+bidObj.getB_contact_no());	
			System.out.println("bidder:"+bidObj.getB_address());
			System.out.println("bidder:"+bidObj.getB_trader_license());	
			System.out.println("bidder:"+bidObj.getB_pincode());
			System.out.println("bidder:"+bidObj.getB_city());	
			System.out.println("bidder:"+bidObj.getB_state());
			System.out.println("bidder:"+bidObj.getB_adharcard());	
			System.out.println("bidder:"+bidObj.getB_account_number());
			System.out.println("bidder:"+bidObj.getB_ifsc());	
			System.out.println("bidder:"+bidObj.getB_bank_name());
			
		}
	}


	
}
