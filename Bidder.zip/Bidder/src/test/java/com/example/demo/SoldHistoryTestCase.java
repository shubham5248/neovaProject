package com.example.demo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Bidder;
import com.example.demo.layer2.SoldHistory;
import com.example.demo.layer3.SoldHistoryImpl;

@SpringBootTest
public class SoldHistoryTestCase {

	@Autowired
	SoldHistoryImpl soldHistObj;
	  @Test
		void insertSoldHistory() {
			SoldHistory shobj =new SoldHistory ();
			
			shobj.setS_date(LocalDate.of(2021, 03, 05));
			shobj.setS_cropName("Bajra");
			shobj.setS_qty("100kg");
			shobj.setS_msp("xyz");
			shobj.setS_soldPrice(14000);
			shobj.setS_totalPrice(14000);
			soldHistObj.insertSoldHistory(shobj);
		}
	  
	  
	  @Test
	  void updateSoldHistory() {
			SoldHistory shobj = null;
			shobj =  soldHistObj.find(SoldHistory.class, 25);
			
			
			shobj.setS_date(LocalDate.of(2021, 05, 25));
			shobj.setS_cropName("Wheat");
			shobj.setS_qty("150kg");
			shobj.setS_msp("xyz");
			shobj.setS_soldPrice(15000);
			shobj.setS_totalPrice(15000);
			soldHistObj.updateSoldHistory(shobj);
			
	  }
	  
	  @Test
	  void findSoldHistory() {
		 SoldHistory soldHistory= soldHistObj.find(SoldHistory.class, 44);
		 System.out.println("SoldHIstory = "+soldHistory.getS_date());
		 System.out.println("SoldHIstory = "+soldHistory.getS_cropName());
		 System.out.println("SoldHIstory = "+soldHistory.getS_qty());
		 System.out.println("SoldHIstory = "+soldHistory.getS_msp());
		 System.out.println("SoldHIstory = "+soldHistory.getS_soldPrice());
		 System.out.println("SoldHIstory = "+soldHistory.getS_totalPrice());
		 
		 
	  }
	  
	  @Test
	  void findAllSoldHistory() {
			List<SoldHistory> shobj =new ArrayList<SoldHistory> ();
		  shobj= soldHistObj.selectSoldHistorys();
		  
		  for(SoldHistory soldHistory : shobj) {
				 System.out.println("SoldHIstory = "+soldHistory.getS_date());
				 System.out.println("SoldHIstory = "+soldHistory.getS_cropName());
				 System.out.println("SoldHIstory = "+soldHistory.getS_qty());
				 System.out.println("SoldHIstory = "+soldHistory.getS_msp());
				 System.out.println("SoldHIstory = "+soldHistory.getS_soldPrice());
				 System.out.println("SoldHIstory = "+soldHistory.getS_totalPrice());
				 
		  }
	  }
	  
	  
	  
		
		@Test
		void deleteSoldHistory()
		{
//			SoldHistory delete=null;
//	    	delete=	  soldHistObj.find(SoldHistory.class, 25);
//	    	soldHistObj.remove(SoldHistory.class, 25);
	    	
	    soldHistObj.deleteSoldHistory(44);
	    List<SoldHistory> shobj =new ArrayList<SoldHistory> ();
		  shobj= soldHistObj.selectSoldHistorys();
		  
		  for(SoldHistory soldHistory : shobj) {
				 System.out.println("SoldHIstory = "+soldHistory.getS_date());
				 System.out.println("SoldHIstory = "+soldHistory.getS_cropName());
				 System.out.println("SoldHIstory = "+soldHistory.getS_qty());
				 System.out.println("SoldHIstory = "+soldHistory.getS_msp());
				 System.out.println("SoldHIstory = "+soldHistory.getS_soldPrice());
				 System.out.println("SoldHIstory = "+soldHistory.getS_totalPrice());
				 
		  }
	    
	    
		}
}
